
// stakevipbet-backend/index.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5000;
const SECRET_KEY = 'stakevip_secret_2025';

app.use(cors());
app.use(bodyParser.json());

let matches = [
  {
    id: 1,
    league: 'Peru - Liga 1',
    teamA: 'Alianza Lima',
    teamB: 'Sporting Cristal',
    score: '1 - 2',
    time: "55'", 
    odds: [2.80, 3.25, 2.45],
    currency: 'PEN'
  }
];

// Middleware for admin auth
function authenticate(req, res, next) {
  const key = req.headers['x-secret-key'];
  if (key === SECRET_KEY) return next();
  return res.status(403).json({ message: 'Unauthorized' });
}

// Public route to get matches
app.get('/matches', (req, res) => {
  res.json(matches);
});

// Admin routes
app.post('/admin/match', authenticate, (req, res) => {
  const match = req.body;
  match.id = matches.length + 1;
  matches.push(match);
  res.json({ message: 'Match added', match });
});

app.put('/admin/match/:id', authenticate, (req, res) => {
  const id = parseInt(req.params.id);
  const updated = req.body;
  const index = matches.findIndex(m => m.id === id);
  if (index !== -1) {
    matches[index] = { ...matches[index], ...updated };
    res.json({ message: 'Match updated', match: matches[index] });
  } else {
    res.status(404).json({ message: 'Match not found' });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
